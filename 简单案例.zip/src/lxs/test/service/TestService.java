package lxs.test.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import lxs.test.db.TestDao;

public class TestService {

	TestDao testDao=null;
	
	public TestService() {
		testDao=new TestDao("jtp_user");
	}
	
	
	public void add(Map<String, Object>map) {
		try {
			testDao.add(map);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void del(Map<String, Object>map) {
		
		try {
			testDao.del(map);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void update(Map<String, Object>map) {
		try {
			testDao.update(map);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public Map<String, Object> load(Map<String, Object>map) {
		
		try {
			return testDao.load(map);
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public List<Map<String, Object>> list() {
		try {
			return testDao.query();
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	
}
