package lxs.test.controller;

import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Map;

import com.java.tp.Controller;

import lxs.test.service.TestService;

public class TestController extends Controller{

	TestService testService=null;
	Map<String, Object>map=null;
	
	
	public void add() {
		map=getParam(request);
		if (map.size()==0) {
			display("add.jsp");
			return ;
		}
		testService =new TestService();
		testService.add(map);
		display("add.jsp");
	}
	
	public void del() {
		map=getParam(request);
		if (map.size()==0) {
			display("del.jsp");
			return;
		}
		testService=new TestService();
		testService.del(map);
		display("del.jsp");
	}
	
	public void update() {
		map=getParam(request);
		if (map.size()==0) {
			display("update.jsp");
			return ;
		}
		testService =new TestService();
		testService.update(map);
		display("update.jsp");
	}
	
	public void load() {
		map=getParam(request);
		if (map.size()==0) {
			alert("id不能为空", "list");
			return ;
		}
		testService =new TestService();
		Map<String, Object>loadMap=testService.load(map);
		assign("loadMap", loadMap);
		display("showLoad.jsp");
	}
	
	public void list() {
		testService =new TestService();
		List<Map<String, Object>>listMap=testService.list();
		assign("listMap", listMap);
		display("showList.jsp");
	}
	
}
