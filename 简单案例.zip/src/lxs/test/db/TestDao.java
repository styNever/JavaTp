package lxs.test.db;

import com.java.tp.JavaTpDB;

public class TestDao extends JavaTpDB{

	public TestDao(String tabelName) {
		super(tabelName);
	}
	
	
	

}
